# # require 'csv'

# # customers = CSV.read('features/support/mock/customers.csv')

# # CSV.foreach('features/support/mock/customers.csv') do |row|
# #   puts row.inspect
# # end


# # # ###### MODELO 1
# #### CADASTRO CPFs
#   cliente = Hash.new

#   apoio = Hash.new
#   apoio = { :nome => "PADRAO", :cpf => 95658376033, :senha => "abc000" }
#   cliente ["PADRAO"] = apoio

#   apoio = Hash.new
#   apoio = { :nome => "PADRAO2", :cpf => 85119973000, :senha => "abc123" }
#   cliente ["PADRAO2"] = apoio


#   puts cliente["PADRAO"][:cpf]
#   puts cliente["PADRAO2"][:senha]
#   puts cliente
  
# # ####### MODELO 2
# # require 'csv'

# # #CSV.foreach("features/support/mock/user_mock.csv", "wb", :write_headers=> true, :headers =>["article_category_id", "articleID", "udid"]) do |csv|
# # CSV.foreach("features/support/mock/user_mock.csv", write_headers: true, :headers =>["article_category_id", "articleID", "udid"]) do |row|


# # #puts "foreach"
# # puts row

# # CSV.open("features/support/mock/Old.csv", "wb") do |csv|
# #   csv << ['article_category_id']=row['article_category_id']
# #   puts "OPEN"
# #   puts csv
# # end

# # # CSV.open('features/support/mock/Old.csv', :headers=>true) do |row|


# # # csv['article_category_id']=row['article_category_id'].to_i
# # # csv['articleID']=row['articleID'].to_i

# # # unless udids.include?(row['udid'])
# # # udids << row['udid']
# # # end
# # # csv['udid'] = udids.index(row['udid']) + 1

# # # csv<<row
# # # end
# # end

# # ...csv << ['article_category_id']=row['article_category_id']


cliente = Hash.new

apoio = Hash.new
apoio = { :nome => "PADRAO", :cpf => 95658376033, :senha => "abc000" }
cliente ["PADRAO"] = apoio

apoio = Hash.new
apoio = { :nome => "PADRAO2", :cpf => 85119973000, :senha => "abc123" }
cliente ["PADRAO2"] = apoio