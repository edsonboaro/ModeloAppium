## entendo que sempre este arquivo sempre é iniciado no inicio
require "appium_lib"
require "appium_console"
require "pry"
require "report_builder"

DEVICE = ENV["DEVICE_TYPE"]

##Configuração do Appium para carregar o Capability
caps = Appium.load_appium_txt file: File.expand_path("caps/#{DEVICE}/appium.txt", __dir__), verbose: true ## Aqui indica que o arquivo de Capability esta nessa pasta
Appium::Driver.new(caps, true) ## Aqui SOBE o driver do APPIUM
Appium.promote_appium_methods Object