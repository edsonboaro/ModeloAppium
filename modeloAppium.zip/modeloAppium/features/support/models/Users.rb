class Users
  attr_accessor :name, :cpf, :senha

  def initialize(name, cpf, senha)
    @name = name
    @cpf = cpf
    @senha = senha
  end
end
