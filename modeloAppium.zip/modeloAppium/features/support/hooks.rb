#require "report_builder"
#require "date"

Before do
  driver.start_driver ##Inicializa Driver do APPIUM
  driver.manage.timeouts.implicit_wait = 10

  @screen = DroidScreens.new if DEVICE.eql?("android")

  if DEVICE.eql?("ios")
    @screen = IOSScreens.new
    @screen.allow_notifications
  end
end

Before("@login_fixed") do ## Aqui eu crio uma notação para todos os cenarios que necesitam fazer login antes da execução lembrando q tem uma diferença entre o fluxo de teste de login e o login em si
  @screen.welcome.comecar
  @screen.login.cpf(85119973000)
  @screen.login.password("abc123")
end

After("@logout_fixed") do ## # Aqui eu crio uma notação para todos os cenarios que necesitam finalizar algo no final de todos os testes, por exemplo sair do usuario / esvaziar um carrinho de compras, etc
  if DEVICE.eql?("ios")
    @screen.menu.mais
    @screen.menu.sair
    @screen.accept_popup
  end
  driver.quit_driver #Finaliza Driver do APPIUM
end

After("@logout") do
  driver.quit_driver #Finaliza Driver do APPIUM
end

After do
  #puts scenario.__id__ ## este comando apresenta o ID da execução é um por execução
  #screenshot = driver.screenshot_as("log/#{scenario.__id__}.png") ##DESCOBRIR PQ NAO FUNCIONA
  screenshot = driver.screenshot_as(:base64) ##tirando print de cada cenario
  embed(screenshot, "image/png", "Screenshot")
  #driver.quit_driver #Finaliza Driver do APPIUM
end

###Só executa depois que o CUCUMBER finaliza todos os testes
at_exit do
  @infos = {
    "device" => DEVICE.upcase,
    "environment" => "Dev",
    "Data do Teste" => DateTime.now.to_s,
  }

  ReportBuilder.configure do |config|
    config.input_path = "log/report.json"
    config.report_path = "log/report"
    config.report_types = [:html]
    config.report_title = "App Mobile"
    config.additional_info = @infos
    config.color = "indigo"
  end
  ReportBuilder.build_report ## Esse compila para fazer funcionar
end
