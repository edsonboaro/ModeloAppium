require_relative "ios_screens"

class IOSScreens
  attr_accessor :welcome, :login, :home, :menu, :ir, :atendimento

  def initialize
     @welcome = IOS::Welcome.new
     @login = IOS::Login.new
     @home = IOS::Home.new
     @menu = IOS::Menu.new
     @ir = IOS::Ir.new
     @atendimento = IOS::Atendimento.new


  end

  def popup
    find_element(xpath: "//XCUIElementTypeAlert[@name='Sair']")
  end

  def canceled_popup
    find_element(xpath: "//XCUIElementTypeButton[@name='Cancelar']").click
  end

  def accept_popup
    find_element(xpath: "//XCUIElementTypeButton[@name='Sair']").click
  end

  def allow_notifications
    target = find_element(xpath: "//XCUIElementTypeAlert//XCUIElementTypeButton[@name='Allow']")
    target.click if target.displayed?
  end

end