module IOS
  class Welcome
    def bemvindo
      find_element(xpath: "//XCUIElementTypeApplication[@name='app (Dev)']/XCUIElementTypeWindow[1]")
    end

    def comecar
      find_element(xpath: "//XCUIElementTypeButton[@name='btnComecar']").click
    end
  end

  class Login
    def cpf(cpf)
      find_element(xpath: "//XCUIElementTypeTextField[@name='campoCPF']").send_keys(cpf)
      find_element(xpath: "//*[contains(@name, 'Olá')]").click
      find_element(xpath: "//XCUIElementTypeStaticText[@name='Continuar']").click
    end

    def password(password)
      find_element(xpath: "//XCUIElementTypeSecureTextField[@name='campoSenha']").send_keys(password)
      find_element(xpath: "//*[contains(@name, 'Olá')]").click
      find_element(xpath: "//XCUIElementTypeStaticText[@name='Entrar']").click
    end
  end

  class Home
    def main
      find_element(name: "app.HomeView")
    end
  end

  class Ir
    def main_ir
      find_element(xpath: "//XCUIElementTypeStaticText[@name='Demonstrativo de IR ']").text.strip
    end
  end

  class Atendimento
    def main_atendimento
      find_element(xpath: "//XCUIElementTypeStaticText[@name='Precisa de ajuda? Entre em contato por um dos nossos canais.']").text
    end
  end

  class Menu
    def inicio
      find_element(xpath: "//XCUIElementTypeButton[@name='home']").click
    end

    def ir
      find_element(xpath: "//XCUIElementTypeButton[@name='document']").click
    end

    def atendimento
      find_element(xpath: "//XCUIElementTypeButton[@name='chat']").click
    end

    def mais
      find_element(xpath: "//XCUIElementTypeButton[@name='more']").click
    end

    def sair
      find_element(xpath: "//XCUIElementTypeStaticText[@name='Sair']").click
    end
  end
end

#### provavelmente vou usar algo parecido com isso para navegar no menu... lembrar de colocar dentro de uma classe curso appium 03 1:02h
# attr_reader :menu

# def initialize
#   @menu = "qaninja.com.pixel:id/ibnt_icon_iv"
# end

# def go_account
#   find_element(id: "qaninja.com.pixel:id/accountButt").click
# end

# def choose_cat(cat)
#   find_elements(id: "cCatNameTxt").text(cat.upcase!).click
# end

# def go_back
#   find_element(xpath: "//android.widget.ImageButton[@content-desc='Navegar para cima']").click
# end

# def go_to_home
#   find_elements(id: @menu)[0].click
# end

# def go_to_wi
#   find_elements(id: @menu)[1].click
# end

# def go_to_cart
#   find_elements(id: @menu)[2].click
# end

# def go_to_contact
#   find_elements(id: @menu)[3].click
# end
# end
