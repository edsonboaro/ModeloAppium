#Essa eh a classe DroidScreens que instancia a camada de implementação do page Objetive ou screen objective (screens) 
require_relative "android_screens"

class DroidScreens
  attr_accessor :welcome, :login, :home, :menu, :ir, :atendimento

   def initialize
        @welcome = Android::Welcome.new
        @login = Android::Login.new
        @home = Android::Home.new
        @menu = Android::Menu.new
        @ir = Android::Ir.new
        @atendimento = Android::Atendimento.new
        #@my_account = MyAccount.new
        #@product = Product.new
        #@cart = Cart.new
   end

################# AQUI é COLOCADO Telas especificas de Android as padrões do SISTEMA OPERACIONAL, ex: popups
  def popup
    find_element(id: "android:id/content")
  end

  def canceled_popup
    find_element(id: "android:id/button2").click
  end

  def accept_popup
     find_element(id: "android:id/button1").click
  end
##################
end