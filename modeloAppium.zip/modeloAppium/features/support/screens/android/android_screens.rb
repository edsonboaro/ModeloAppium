module Android
  class Welcome
    def bemvindo
      find_element(id: "br.com.app.dev:id/action_bar_root")
    end

    def comecar
      find_element(id: "br.com.app.dev:id/walkthough_start").click
    end
  end

  class Login
    def cpf(cpf)
      find_element(id: "br.com.app.dev:id/documentValidationDocument").send_keys(cpf)
      find_element(id: "br.com.app.dev:id/documentValidationCarryOn").click
    end

    def password(password)
      find_element(id: "br.com.app.dev:id/passwordValidationPassword").send_keys(password)
      find_element(id: "br.com.app.dev:id/passwordValidationEnter").click
    end
  end

  class Home
    def main
      find_element(id: "br.com.app.dev:id/home_plan_list")
    end
  end

  class Ir
    def main_ir
      find_element(id: "br.com.app.dev:id/income_tax_title").text
    end
  end

  class Atendimento
    def main_atendimento
      find_element(id: "br.com.app.dev:id/support_subtitle").text
    end
  end

  class Menu
    def inicio
      find_elements(id: "br.com.app.dev:id/smallLabel").text("Início").click
    end

    def ir
      find_element(id: "br.com.app.dev:id/smallLabel").click
    end

    def atendimento
      find_elements(id: "br.com.app.dev:id/smallLabel").text("Atendimento").click
    end

    def mais
      find_elements(id: "br.com.app.dev:id/smallLabel").text("Mais").click
    end

    def sair
      find_elements(id: "br.com.app.dev:id/textview_profile_logout").text("Sair").click
    end
  end
end
