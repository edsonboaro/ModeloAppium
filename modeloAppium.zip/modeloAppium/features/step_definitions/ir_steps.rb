Quando("eu clicar em IR") do
	@screen.menu.ir
end
  
Então("posso ver a tela de IR") do
	expect(@screen.ir.main_ir).to eql "Demonstrativo de IR"
end