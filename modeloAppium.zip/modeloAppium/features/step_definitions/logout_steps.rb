Dado("que eu esteja logado na tela home") do
    expect(@screen.home.main.displayed?).to be true
end

Quando("eu clicar em Mais, Sair") do
    @screen.menu.mais
    @screen.menu.sair
end

Quando("confirmar") do
    @screen.accept_popup
end

Entao("posso ver a tela de Bem Vindo") do
    expect(@screen.welcome.bemvindo.displayed?).to be true
end