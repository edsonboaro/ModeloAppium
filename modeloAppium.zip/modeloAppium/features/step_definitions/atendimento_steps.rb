Quando("eu clicar em atendimento") do
	@screen.menu.atendimento
end
  
Então("posso ver a tela de atendimento") do
	expect(@screen.atendimento.main_atendimento).to eql "Precisa de ajuda? Entre em contato por um dos nossos canais."
end