Dado("que eu clique no botão Começar") do
	@screen.welcome.comecar
end
  
Quando("eu informo o CPF {int} e clico em Continuar") do |cpf|
	@screen.login.cpf(cpf)
end
  
Quando("informo a senha {string} e clico em Entrar") do |password|
	@screen.login.password(password)
end
  
Então("posso ver a tela de Home") do
	expect(@screen.home.main.displayed?).to be true
end