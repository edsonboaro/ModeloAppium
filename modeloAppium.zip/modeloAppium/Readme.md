Comando para gerar relatorio
cucumber -t @login --format html --out=log/report.html

Rodar emulador
emulator -avd Pixel_XL_API_28

Users/edson.boaro/Library/Developer/Xcode/DerivedData/App-alouaigybygipwaxumwfrcmifmua/Build/Products/Dev-Debug-iphonesimulator/NomeApp.app

Arc
 cd features/support/caps/

 Capibility do iOS para o Appium desktop
 {
  "automationName": "XCUITest",
  "platformName": "iOS",
  "platformVersion": "13.3",
  "deviceName": "iPhone 11 Pro Max",
  "app": "/Users/edson.boaro/projetos/App/App-automacao/App.app",
  "noReset": false,
  "locationServicesAuthorized": true,
  "locationServicesEnabled": true,
  "newCommandTimeout": 100000,
  "adbExecTimeout": 100000,
  "connectHardwareKeyboard": false,
  "autoAcceptAlerts": false,
  "autoDismissAlerts": false,
  "autoGrantPermissions": true,
  "sendKeyStrategy": "grouped"
}